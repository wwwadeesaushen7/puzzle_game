@echo off
cd /d "%~dp0"
start "" "AstralForge.exe" --rendering-method forward_plus
