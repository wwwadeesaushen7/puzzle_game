ASTRAL FORGE — WINDOWS

Run AstralForge.exe. The game is self-contained and works offline.
Default graphics use OpenGL Compatibility for broad laptop support.
Low Graphics.cmd starts Low quality. Advanced Graphics.cmd requests
Forward+ on a suitable Vulkan-capable GPU; Godot may fall back on older hardware.

Click an uncovered relic. Three identical relics clear the collection.
Clear the board to win; filling seven slots without a match ends the expedition.
Mouse wheel: zoom. Right drag: orbit. Esc: pause. F11: fullscreen.
U: Undo; R: Reweave; H: Hint; E: extra slot; Space: rotate; F: shift.
Abilities use earned coins; restarting is free and every level is solvable
without abilities. Saves are local to your user account.

This executable was exported and its embedded game pack was smoke-tested
in the Linux development environment. Native Windows hardware QA remains
necessary. See VALIDATION.md for the exact tested scope and remaining work.
Third-party engine/font notices are included in LICENSES and in Settings.
