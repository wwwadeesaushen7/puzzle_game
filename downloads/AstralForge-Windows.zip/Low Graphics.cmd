@echo off
cd /d "%~dp0"
start "" "AstralForge.exe" --rendering-method gl_compatibility -- --low
